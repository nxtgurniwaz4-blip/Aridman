import SwiftUI

struct Activity: Identifiable {
    let id = UUID()
    let title: String
    let emoji: String
    let color: Color
    let subtitle: String
}

struct HomeView: View {
    private let activities = [
        Activity(title: "Tractors", emoji: "🚜", color: .green, subtitle: "Drive & discover"),
        Activity(title: "Buses", emoji: "🚌", color: .blue, subtitle: "Beep & roll"),
        Activity(title: "Farm", emoji: "🌾", color: .orange, subtitle: "Explore the farm"),
        Activity(title: "Big Trucks", emoji: "🚛", color: .red, subtitle: "Tap the trucks"),
        Activity(title: "Animals", emoji: "🐄", color: .purple, subtitle: "Meet the animals"),
        Activity(title: "Match", emoji: "🧩", color: .teal, subtitle: "Find the vehicle")
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [Color(red: 0.92, green: 0.98, blue: 0.91),
                                         Color(red: 0.80, green: 0.94, blue: 0.99)],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 22) {
                        VStack(spacing: 4) {
                            Text("Aridman’s").font(.system(size: 38, weight: .black, design: .rounded))
                            Text("Happy Place").font(.system(size: 44, weight: .black, design: .rounded))
                            Text("🚜  🚌  🌾  🐄").font(.system(size: 34))
                        }.padding(.top, 20)

                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 18)], spacing: 18) {
                            ForEach(activities) { activity in
                                NavigationLink {
                                    ActivityView(activity: activity)
                                } label: {
                                    VStack(spacing: 10) {
                                        Text(activity.emoji).font(.system(size: 62))
                                        Text(activity.title).font(.system(size: 25, weight: .black, design: .rounded))
                                        Text(activity.subtitle).font(.system(size: 16, weight: .semibold, design: .rounded)).opacity(0.75)
                                    }
                                    .foregroundStyle(.primary)
                                    .frame(maxWidth: .infinity, minHeight: 165)
                                    .background(RoundedRectangle(cornerRadius: 30).fill(activity.color.opacity(0.20)))
                                    .overlay(RoundedRectangle(cornerRadius: 30).stroke(activity.color.opacity(0.35), lineWidth: 2))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal)
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
}

struct ActivityView: View {
    let activity: Activity
    @State private var bounce = false
    @State private var count = 0

    var body: some View {
        ZStack {
            activity.color.opacity(0.12).ignoresSafeArea()
            VStack(spacing: 28) {
                Text(activity.emoji).font(.system(size: 150))
                    .scaleEffect(bounce ? 1.12 : 1)
                    .animation(.spring(response: 0.3, dampingFraction: 0.55), value: bounce)
                Text(activity.title).font(.system(size: 44, weight: .black, design: .rounded))
                Text("Tap it!").font(.system(size: 30, weight: .bold, design: .rounded))
                Button {
                    count += 1
                    bounce = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.22) { bounce = false }
                } label: {
                    Text("TAP! 👆")
                        .font(.system(size: 34, weight: .black, design: .rounded))
                        .frame(maxWidth: 420, minHeight: 95)
                        .background(RoundedRectangle(cornerRadius: 30).fill(activity.color))
                        .foregroundStyle(.white)
                }.buttonStyle(.plain)
                Text("Fun taps: \(count)").opacity(0.65)
            }.padding(30)
        }
        .navigationTitle(activity.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
