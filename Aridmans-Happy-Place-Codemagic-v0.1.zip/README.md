# Aridman’s Happy Place — Codemagic-ready iOS project

Bundle ID: `com.aridman.happyplace`
Display name: `Aridman’s Happy Place`
Target: iPhone + iPad
Minimum iOS: 17.0

## Codemagic
The repository contains `codemagic.yaml` at its root. The workflow:
1. Installs XcodeGen.
2. Generates `AridmansHappyPlace.xcodeproj` from `project.yml`.
3. Applies Codemagic iOS signing profiles.
4. Builds a distribution IPA.
5. Exposes the IPA as a Codemagic artifact.

For signing, configure the appropriate Apple signing credentials in Codemagic. Do not put private `.p12` passwords or certificates in the repository.

## Local Xcode
On a Mac with Xcode and XcodeGen:
`xcodegen generate --spec project.yml`
Then open `AridmansHappyPlace.xcodeproj`.

## Current v0.1
- Tractor, bus, farm, truck, animal and matching activities
- Large touch targets and simple animations
- iPhone/iPad adaptive grid
- Original app icon asset set
- No external dependencies
- No network/video dependency
